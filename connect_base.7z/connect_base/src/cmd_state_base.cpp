#include <ros/ros.h>
#include <cmd_state_base.h>
#include "scout_msg/ScoutStatus.h"

motion_cmd::motion_cmd(ros::NodeHandle nh)
{
    subwarn =new message_filters::Subscriber<obstacle_avoidance::motioncmd>(subnode, "warner", 5);
  subwarn->registerCallback(boost::bind(&motion_cmd::callback, this, _1));
    stapub =nh.advertise <scout_msg::ScoutStatus>("ScoutStatus", 10);
    cmdsub = nh.subscribe<geometry_msgs::Twist> ("ScoutMotionCmd",10,boost::bind(&motion_cmd::comcmd, this, _1));
}

motion_cmd::~motion_cmd()
{
}

void motion_cmd::callback(const obstacle_avoidance::motioncmd::ConstPtr & msg)
{
    warnsub = msg->warner;
        ROS_INFO("shiyishi02");
  
  switch (warnsub)
  {
  case 1:
     {
         
     }
      break;
      case 2:
      {
          rcvcmd.angular.z=0;
          rcvcmd.linear.y = 0;
      }
  break;

  case 3:
  {
      rcvcmd.angular.z = 2;
      rcvcmd.linear.y = 0;
  }
  break;
  default:
      break;
  }
  ROS_INFO("warner = %d",warnsub);
  
}

void motion_cmd::getwarn(geometry_msgs::Twist &cmd)
{

}

void motion_cmd::comcmd(const geometry_msgs::Twist::ConstPtr &msg)
{
    ROS_INFO("ysubb=%.2f",msg->linear.y);
    rcvcmd.linear=msg->linear;
    rcvcmd.angular=msg->angular;
    if (warnsub != 1)
    {
         rcvcmd.linear.y=0;
         rcvcmd.angular.z=0;
    }

   ROS_INFO("comcmd");
   ROS_INFO("ysub=%.2f",msg->linear.y);
}