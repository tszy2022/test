#ifndef TIMER_BASE_H
#define TIMER_BASE_H

#include <array>
#include <chrono>
#include <cstdint>
#include <algorithm>
#include <thread>

struct Timer
{
    using Clock = std::chrono::high_resolution_clock;
    using time_point = typename Clock::time_point;
    using duration = typename Clock::duration;

    Timer()
    {
        tic_point = Clock::now();
    };

    time_point tic_point;

    void reset()
    {
        tic_point = Clock::now();
    };//返回当前的时间，精确度较高

    // you have to call reset() before calling sleep functions
    void sleep_until_ms(int64_t period_ms)
    {
        int64_t duration =
            period_ms - std::chrono::duration_cast<std::chrono::milliseconds>(
                Clock::now() - tic_point)
            .count();
        if (duration > 0)
            std::this_thread::sleep_for(std::chrono::milliseconds(duration));
    };

    void sleep_until_us(int64_t period_us)
    {
        int64_t duration =
            period_us - std::chrono::duration_cast<std::chrono::microseconds>(
                Clock::now() - tic_point)
            .count();
        if (duration > 0)
            std::this_thread::sleep_for(std::chrono::microseconds(duration));
    };
};

#endif