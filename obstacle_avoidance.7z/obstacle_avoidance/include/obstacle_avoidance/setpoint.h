#ifndef SETPOINT_H
#define SETPOINT_H
#include <ros/ros.h>
#include "message_filters/subscriber.h"
#include "nav_msgs/GetMap.h"
#include "nav_msgs/MapMetaData.h"
#include<geometry_msgs/PointStamped.h>
#include <gmapping/utils/point.h>
#include <tf2_ros/transform_listener.h>
#include<tf2_ros/buffer.h>

class setpoint
{
private:
    
    message_filters::Subscriber<nav_msgs::OccupancyGrid> *submap;
    void responcemap(const nav_msgs::OccupancyGrid::ConstPtr &msg);
    ros::Publisher pubmap;
    ros::Publisher pubpoint;
    tf2_ros::Buffer buffer;


public:
    setpoint(ros::NodeHandle nh,double startx,double starty,double endx,double endy);
    ~setpoint();
    double delta_;
    nav_msgs::GetMap::Response mapsub;
    geometry_msgs::PointStamped startpoint;
    geometry_msgs::PointStamped endpoint;
    void transpoint();
    bool firstgot;
    GMapping::OrientedPoint posesub;
    geometry_msgs::TransformStamped trans;
    };




#endif