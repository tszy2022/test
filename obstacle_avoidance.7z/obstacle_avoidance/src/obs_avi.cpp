#include<ros/ros.h>
#include "message_filters/subscriber.h"
#include "sensor_msgs/LaserScan.h"
#include <math.h>
#include "std_msgs/String.h"
#include "stop_test.h"
#include "setpoint.h"
#include "trackmap.h"

int main(int argc, char  *argv[])
{     
    ros::init(argc,argv,"stop_test");
    ros::NodeHandle obs_avi;
    ros::Duration(2).sleep(); 
    ROS_INFO("obs_avi");

    

    stop_test stop_t(obs_avi);
    trackmap track(obs_avi);
    ROS_INFO("trackamp_finish");
    //setpoint getpoint(obs_avi,0.0,0.0,20.0,20.0);
    ros::spin();
    return 0;
}