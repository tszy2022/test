#include "ros/ros.h"
#include "trackmap.h"

void trackmap::Client_thread()
{
    // mappoint = YAML::LoadFile("/home/syjk/driverless_car/robot_ws/src/obstacle_avoidance/src/mappoint.yaml");
    // float xi = mappoint["mappoint"]["x"].as<float>();
    // ROS_INFO("%f",xi);
    // xi = mappoint["mappoint"]["x"].as<float>();
    // ROS_INFO("%f",xi);
    ROS_INFO("Client_thread");
    track.request.x[0]=1;
    track.request.y[0]=0;
    track.request.x[1]=1;
    track.request.y[1]=-1;
      
      bool flag= clienttrack.call(track);

}

    void trackmap::start_client_thread(ros::NodeHandle nh)
    {
        ROS_INFO("start_client_thread");
        clienttrack = nh.serviceClient<obstacle_avoidance::track>("trackmsg");
         client_thread=std::thread(&trackmap::Client_thread, this);
    }


