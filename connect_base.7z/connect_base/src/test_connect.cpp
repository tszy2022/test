#include<ros/ros.h>
#include<test_connect.h>
#include <stdio.h>
#include <string.h>
#include <unistd.h>
#include <netdb.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <arpa/inet.h>
#include <mutex>
#include <thread>
#include <aio.h>
#include <sys/ioctl.h>
#include <linux/sockios.h>
#include "ros/ros.h"

test_connect::test_connect(int baud):Connector(baud)
{
    
}

int test_connect::Send(const void *buf,const int buflen)
{
    return send(m_sockfd,buf,buflen,0);
}

int test_connect::Recv(void *buf,const int buflen)
{
    return recv(m_sockfd,buf,buflen,0);
}
int test_connect::Read(void *buf,const int buflen)
{
    return read(m_sockfd,buf,buflen);
}
int test_connect::Write(void *buf,const int buflen)
{
    return write(m_sockfd,buf,buflen);
}

int test_connect::init()
{

    if (ConnectToServer("192.168.1.10",4001)==false)
    {
        printf("TcpClient.ConnectToServer(\"192.168.1.10\",4001) failed,exit...\n");
        return 0;
    }

    else
    {
        unsigned char strbuffer[13]= {0x08,0x00,0x00,0x04,0x21,0x01,0x00,0x00,0x00,0x00,0x00,0x00,0x00};
        Send(strbuffer,13);
        unsigned char strbuffer0[13]= {0x08,0x00,0x00,0x01,0x21,0x01,0x01,0x05,0x01,0x05,0x00,0x00,0x00};

        unsigned char strbuffer1[13]= {0x08,0x00,0x00,0x01,0x21,0x01,0x00,0x00,0x00,0x00,0x00,0x00,0x00};

        unsigned char strbuffer2[13]= {0x08,0x00,0x00,0x01,0x21,0x01,0x01,0x05,0x01,0x05,0x00,0x00,0x00};

//char strbuf1[8] {\000,\000,\000,\000,\000,\000,\000,\b};
        Send(strbuffer0,13);
        sleep(1);
        Send(strbuffer1,13);
        sleep(1);
        Send(strbuffer2,13);
        sleep(1);
        printf("initialization completed. \n");
        
//std::thread read_thread();
int a=0;
int b=0;
//std::thread read_thread();
if(test_connect::start_control_thread())
{
     a=1;
}
else
{
    ROS_ERROR("start_control_thread failed");
}

if(test_connect::start_read_thread())
{
    b=1;
}
else
{
    ROS_ERROR("start_read_thread failed");
}

if(a&b)
{
    return 1;
}
else
{
    return 0;
}


    }

}


void test_connect::unpack_all() //打印一次所有信息，调试专用函数
{
    for (int count{ 0 }; count <= 100; ++count)
    {
        // printf("%d",count);
        if (Read(rec_buffer0,sizeof(rec_buffer0))<=0) break;
        //    memcpy(&mgs.raw, rec_buffer0+5,8 * sizeof(uint8_t));
        //   printf("%0x  \n",&(rec_buffer0[0]));
        copy_to_can_frame(can_frame_pt, &(rec_buffer0[0]));
        DecodeCanFrame(can_frame_pt, agx_msg_pt);
        convert_data_once(agx_msg,scout_state);
        //上面三步之后，所有状态储存在scout_state里面

//            for (int j{ 0 }; j <=12; ++j)
//                {
//                    printf("%0x  ",rec_buffer0[j]);
//                }
//                printf("****\n");
//                   for (int j{ 0 }; j <=7; ++j)
//                {
//                   printf("%0x ",mgs.raw[j]);
//                   //printf("%0x  ",mgs.cmd);
//
//                }
//                printf("****\n");
//        //       printf("%0x ",can_frame_pt->can_id);
//
//                printf("end  \n");
//                sleep(1);
    }
    printall();

}





void test_connect::printall()//打印一次所有信息，调试专用函数
{
    const std::lock_guard<std::mutex> lock(scout_state_mutex);
    //读取之前防止翻转状态，上锁
    printf("display current state: \n");
    printf("base_state：%0x \n",scout_state.base_state);
    printf("control_mode：%0x \n",scout_state.control_mode);
    printf("fault_code：%0x \n",scout_state.fault_code);
    printf("battery_voltage：%f volts \n",scout_state.battery_voltage);
    printf("\n \n --motor state----------------------------------------segment-- \n \n");

    printf("FRONT_RIGHT motor_current：%f A \n",scout_state.actuator_states[0].motor_current);
    printf("FRONT_LEFT motor_current：%f A \n",scout_state.actuator_states[1].motor_current);
    printf("REAR_LEFT motor_current：%f A \n",scout_state.actuator_states[2].motor_current);
    printf("REAR_RIGHT motor_current：%f A \n",scout_state.actuator_states[3].motor_current);

    printf("FRONT_RIGHT motor_rpm：%f  \n",scout_state.actuator_states[0].motor_rpm);
    printf("FRONT_LEFT motor_rpm：%f  \n",scout_state.actuator_states[1].motor_rpm);
    printf("REAR_LEFT motor_rpm：%f  \n",scout_state.actuator_states[2].motor_rpm);
    printf("REAR_RIGHT motor_rpm：%f  \n",scout_state.actuator_states[3].motor_rpm);

    printf("FRONT_LEFT motor_rpm：%f  \n",scout_state.actuator_states[0].motor_rpm);
    printf("FRONT_LEFT motor_rpm：%f  \n",scout_state.actuator_states[1].motor_rpm);
    printf("FRONT_LEFT motor_rpm：%f  \n",scout_state.actuator_states[2].motor_rpm);
    printf("FRONT_LEFT motor_rpm：%f  \n",scout_state.actuator_states[3].motor_rpm);


    printf("FRONT_LEFT driver_voltage：%f V \n",scout_state.actuator_states[0].driver_voltage);
    printf("FRONT_LEFT driver_voltage：%f V \n",scout_state.actuator_states[1].driver_voltage);
    printf("FRONT_LEFT driver_voltage：%f V \n",scout_state.actuator_states[2].driver_voltage);
    printf("FRONT_LEFT driver_voltage：%f V \n",scout_state.actuator_states[3].driver_voltage);

    printf("\n \n --light state----------------------------------------segment-- \n \n");

    printf("light_control_enabled %d \n",scout_state.light_control_enabled);
    printf("front_light_state mode:%0x   ***** custom_value:%0x  \n ",scout_state.front_light_state.mode,scout_state.front_light_state.custom_value);
    printf("rear_light_state mode:%0x   ***** custom_value:%0x  \n ",scout_state.rear_light_state.mode,scout_state.rear_light_state.custom_value);

    printf("\n \n --motion state----------------------------------------segment-- \n \n");
    printf("linear_vel:%f m/s \n",scout_state.linear_velocity);
    printf("angular_velocity:%f rad/s \n",scout_state.angular_velocity);

    printf("\n \n --odometer state----------------------------------------segment-- \n \n");
    printf("left_odometry:%f m right_odometry:%f m \n",scout_state.left_odometry,scout_state.right_odometry);

    printf("\n \n --BMS state----------------------------------------segment-- \n \n");
    printf("bms_battery_voltage:%d V \n",scout_state.bms_battery_voltage);
    printf("battery_current:%f A \n",scout_state.battery_current);

    printf("\n \n --temperature----------------------------------------segment-- \n \n");
    printf("FRONT_RIGHT motor_temperature:%f  \n",scout_state.actuator_states[0].motor_temperature);
    printf("FRONT_LEFT motor_temperature:%f  \n",scout_state.actuator_states[1].motor_temperature);
    printf("REAR_LEFT motor_temperature:%f  \n",scout_state.actuator_states[2].motor_temperature);
    printf("REAR_RIGHT motor_temperature:%f  \n",scout_state.actuator_states[3].motor_temperature);

    printf("battery_temperature:%f \n",scout_state.battery_temperature);


//读取之后解锁
    const std::lock_guard<std::mutex> unlock(scout_state_mutex);
    sleep(0.5);
}






void test_connect::cmd_test()
{
//灯光控制指令,所有指令按照以下标准赋值，不要按照ugvsdk里面到代码赋值
    int i {0};
    ScoutLightCmd cmd {};
    cmd.enable_ctrl=1;
    cmd.front_mode=ScoutLightCmd::LightMode::CONST_OFF;
    cmd.rear_mode=ScoutLightCmd::LightMode::CUSTOM;
    cmd.front_custom_value=0x01;
    cmd.rear_custom_value=0x64;
    SetLightCommand(cmd);
    printf("finish sending Lightcmd \n");
    while(1)
    {
        cmd.front_mode=ScoutLightCmd::LightMode::CONST_ON;
        cmd.rear_mode=ScoutLightCmd::LightMode::CONST_ON;
        SetLightCommand(cmd);
        sleep(1);
        cmd.front_mode=ScoutLightCmd::LightMode::CONST_OFF;
        cmd.rear_mode=ScoutLightCmd::LightMode::CONST_OFF;
        SetLightCommand(cmd);
        printf("finish sending Lightcmd \n");
        sleep(1);

    }

//定义运动控制参数
//定义控制指令类对象
    current_motion_cmd_.angular_velocity=0;
    current_motion_cmd_.linear_velocity=1;
    sleep(0.1);//本代码中所有sleep(小数)指令错误，会直接sleep(0)
    while(1)
    {


        SendMotionCmd();
        printf("sending motioncmd %d \n",i);
//i++;
    }

    printf("finish sending motioncmd \n");

}

