#include "ros/ros.h"
#include "trackmap.h"

trackmap::trackmap(ros::NodeHandle nh)
{  pubcmd.angular.x = 0;
    pubcmd.angular.y = 0;
    pubcmd.angular.z = 0;
    pubcmd.linear.x = 0;
    pubcmd.linear.y = 0;
    pubcmd.linear.z = 0;
    ROS_INFO("trackmap");   
    // trans.transform.translation.x = 0;
    // trans.transform.translation.y = 0;
    // roll = 0;
    // pitch = 0;
    // yam = 0;

    
    cmdpub = nh.advertise<geometry_msgs::Twist>("trackcmd",10,true);
    servertrack = nh.advertiseService ("trackmsg",&trackmap::trackback ,this);
    // ros::service::waitForService("trackmsg");
    start_client_thread(nh);
    
}

trackmap::~trackmap()
{
}


bool trackmap::trackback(obstacle_avoidance::track::Request & reqtrack , obstacle_avoidance::track::Response &restrack)
 {

//     //ROS_INFO("trackback");

    tf2_ros::TransformListener listener(buffer);
    ros::Duration(2).sleep(); 
    ros::Rate r(2);    
    int i = 0;
    while( ros::ok()) 
    {    restrack.dx=10.0;
    restrack.dy=10.0;
         ROS_INFO("reqtrack.x = %.2f\nreqtrack.y = %.2f",reqtrack.x[i],reqtrack.y[i]);
    while (restrack.dx>0.1 || restrack.dy>0.1 ||restrack.dx<-0.1||restrack.dy<-0.1)
    {
   trans= buffer.lookupTransform("map","base_footprint",ros::Time(0)); 
    tf2::Quaternion quat(trans.transform.rotation.x,trans.transform.rotation.y,trans.transform.rotation.z,trans.transform.rotation.w);
    tf2::Matrix3x3(quat).getRPY(roll,pitch,yam);

    restrack.dx = reqtrack.x[i]-trans.transform.translation.x;
    restrack.dy = reqtrack.y[i]-trans.transform.translation.y;
    lengths = hypot((restrack.dx),(restrack.dy));
    

    //计算angles，从-pi/2到pi/2
    if ((restrack.dx) == 0 && (restrack.dy)>0)
    angles = PI/2;
    else if ((restrack.dx) == 0 && (restrack.dy)<0)
    angles = PI/2;
    else
    angles = atan2((restrack.dy),(restrack.dx));

    //修正角度到四个相限
    if ((restrack.dx)<0 && angles <=0)
    {
        angles = angles + PI;
    }
        if ((restrack.dx)<0 && angles >0)
    {
        angles = angles - PI;
    }

    //如果yam的范围是-pi到pi，那么y的范围就是-pi/2到3pi/2

   // 计算角度差，即目标角度与车辆角度之间的角度差，暂时只考虑前进方向，只修正前进方向与目标轨迹之间的角度差，认为只能前进不能后退
    detaang = angles-yam;

    if(detaang >PI)
    {
        detaang = detaang-2*PI;
    }
    if(detaang<-PI)
    {
        detaang = detaang+2*PI;
    }


//ROS_INFO("x=%.2f\ny=%.2f\nz=%.2f\nw=%.2f",trans.transform.rotation.x,trans.transform.rotation.y,trans.transform.rotation.z,trans.transform.rotation.w);
//ROS_INFO("x=%.2f\ny=%.2f\nz=%.2f",trans.transform.translation.x,trans.transform.translation.y,trans.transform.translation.z);
    if(detaang>dangle ||detaang<-dangle)
        pubcmd.angular.z = lwz*detaang;
    else
        pubcmd.angular.z = 0;

    if(pubcmd.angular.z <wmin && pubcmd.angular.z>0)
        pubcmd.angular.z =wmin;
    if(pubcmd.angular.z >-wmin && pubcmd.angular.z<0)
        pubcmd.angular.z = -wmin;
    if(pubcmd.angular.z >wmax)
        pubcmd.angular.z = wmax;
    if(pubcmd.angular.z <-wmax)
        pubcmd.angular.z = -wmax;

    if(lengths>dlength)
        pubcmd.linear.y = lvy*lengths;
    else
        pubcmd.linear.y = 0;
    if(pubcmd.linear.y>vmax)
        pubcmd.linear.y = vmax;
    if(pubcmd.linear.y<vmin)
        pubcmd.linear.y = vmin;

    if(pubcmd.angular.z!=0)
        pubcmd.linear.y = 0;

    cmdpub.publish(pubcmd);    
    ROS_INFO("angle = %.2f\nyam = %.2f\ndetaang = %.2f\nwan = %.2f",angles,yam,detaang,pubcmd.angular.z);
    ROS_INFO("x=%.2f\ny=%.2f\ndx=%.2f\ndy=%.2f\nvel = %.2f\n",trans.transform.translation.x,trans.transform.translation.y,restrack.dx,restrack.dy,pubcmd.linear.y);
    r.sleep();
    }
    if (reqtrack.x[i]==reqtrack.x[i+1]&&reqtrack.y[i]==reqtrack.y[i+1])
    break;
    i++;
    }
    if(i!=0)
    return true;
    else
    return 0;
 }