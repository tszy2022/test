#ifndef MOTION_CMD_H
#define MOTION_CMD_H
#include <ros/ros.h>
#include <std_msgs/String.h>
#include <message_filters/subscriber.h>
#include "obstacle_avoidance/motioncmd.h"
#include "geometry_msgs/Twist.h"

class motion_cmd
{
private:
    ros::NodeHandle subnode;
   message_filters::Subscriber<obstacle_avoidance::motioncmd> *subwarn;
    void callback(const obstacle_avoidance::motioncmd::ConstPtr &msg);
    
    ros::Subscriber cmdsub;
    void comcmd(const geometry_msgs::Twist::ConstPtr &msg);
public:
    
    motion_cmd(ros::NodeHandle nh);
    ~motion_cmd();
    geometry_msgs::Twist rcvcmd;
    uint8_t warnsub;
    void getwarn(geometry_msgs::Twist &cmd);
    ros::Publisher stapub;



};





#endif