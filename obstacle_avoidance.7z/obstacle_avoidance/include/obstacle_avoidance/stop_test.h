#ifndef STOP_TEST_H
#define STOP_TEST_H

#include "ros/ros.h"
#include "sensor_msgs/LaserScan.h"
#include "obstacle_avoidance/motioncmd.h"


#define juli 0.12
#define xmea 0.5
#define ymea 0.6
#define ylim 0.75
#define xlim 0.75
#define ranged 0.75
#define rangex 0.6
#define warngo 1
#define warnstop 2
#define warnright 3
#define warnleft 4
#define noright 5
#define noleft 6
#define onlygo 7




class stop_test
{
 private:
    ros::Publisher pubwarn;
   message_filters::Subscriber<sensor_msgs::LaserScan>* sub_;
   int  backwarner(const sensor_msgs::LaserScan::ConstPtr &msg);
 public:

     obstacle_avoidance::motioncmd warner ;
     
    stop_test(ros::NodeHandle nh);
    ~stop_test();



};




#endif  