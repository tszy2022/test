#include <ros/ros.h>
#include "test_connect.h"
#include<connector_base.h>
#include <tf/transform_broadcaster.h>
#include <stdio.h>
#include<tf2_ros/static_transform_broadcaster.h>
#include <geometry_msgs/TransformStamped.h>
#include<tf2/LinearMath/Quaternion.h>
#include "math.h"
#include "scout_msg/ScoutStatus.h"

auto start = std::chrono::steady_clock::now();
auto end = std::chrono::steady_clock::now();


void setodom(const scout_msg::ScoutStatus::ConstPtr & msg)
{

     tf2_ros::StaticTransformBroadcaster pub1;
     end = std::chrono::steady_clock::now();
     static double position_x_=0;
     static double position_y_=0;
     static double theta_=0;
     std::chrono::duration<double, std::micro> dt0 = end - start;
     double dt=0;
     dt=dt0.count()*0.000001; 
     double linear_speed_ =msg ->linear_velocity;
     double angular_speed_ =msg ->angular_velocity;

     double d_x = linear_speed_ * std::cos(theta_) * dt;
     double d_y = linear_speed_ * std::sin(theta_) * dt;
     double d_theta = angular_speed_ * dt;

     position_x_ += d_x;
     position_y_ += d_y;
     theta_ += d_theta;

     geometry_msgs::TransformStamped tfs4;

     tfs4.header.stamp = ros::Time::now();//定义时间戳

     tfs4.header.frame_id = "odom";

     tfs4.child_frame_id = "base_footprint";

     tfs4.transform.translation.x = position_x_;

     tfs4.transform.translation.y =position_y_;

      tfs4.transform.translation.z = 0.0;

      tf2::Quaternion qtn;//将欧拉角转变为四元数
      
      qtn.setRPY(0,0,theta_);//输入的是欧拉角的弧度值

      tfs4.transform.rotation.x = qtn.getX();//获取欧拉角对应的四元数

      tfs4.transform.rotation.y = qtn.getY();

      tfs4.transform.rotation.z = qtn.getZ();

      tfs4.transform.rotation.w = qtn.getW();
    
      pub1.sendTransform(tfs4);//发布
     
      start = std::chrono::steady_clock::now();
}

int main(int argc,char** argv)
{
    ros::init(argc, argv, "my_tf_broadcaster");
    ros::NodeHandle node;

    tf2_ros::StaticTransformBroadcaster pub;
    geometry_msgs::TransformStamped tfs;
    tfs.header.stamp = ros::Time::now();//定义时间戳
    tfs.header.frame_id = "base_footprint";
    tfs.child_frame_id = "base_link";

    tfs.transform.translation.x = 0.0;
    tfs.transform.translation.y = 0.0;
    tfs.transform.translation.z = 0.0;

    tf2::Quaternion qtn;//将欧拉角转变为四元数
    qtn.setRPY(0,0,0);//输入的是欧拉角的弧度值

    tfs.transform.rotation.x = qtn.getX();//获取欧拉角对应的四元数
    tfs.transform.rotation.y = qtn.getY();
    tfs.transform.rotation.z = qtn.getZ();
    tfs.transform.rotation.w = qtn.getW();

    geometry_msgs::TransformStamped tfs2;

    tfs2.header.stamp = ros::Time::now();//定义时间戳
    tfs2.header.frame_id = "base_link";
    tfs2.child_frame_id = "laser_link";

    tfs2.transform.translation.x = 0.0;
    tfs2.transform.translation.y = 0.0;
    tfs2.transform.translation.z = 0.0;

    tf2::Quaternion qtn2;//将欧拉角转变为四元数
    qtn2.setRPY(0,0,0);//输入的是欧拉角的弧度值

    tfs2.transform.rotation.x = qtn2.getX();//获取欧拉角对应的四元数
    tfs2.transform.rotation.y = qtn2.getY();
    tfs2.transform.rotation.z = qtn2.getZ();
    tfs2.transform.rotation.w = qtn2.getW();
  
    geometry_msgs::TransformStamped tfs3;

    tfs3.header.stamp = ros::Time::now();//定义时间戳
    tfs3.header.frame_id = "base_link";
    tfs3.child_frame_id = "base_scan";

    tfs3.transform.translation.x = 0.0;
    tfs3.transform.translation.y = 0.0;
    tfs3.transform.translation.z = 0.0;

    tf2::Quaternion qtn3;//将欧拉角转变为四元数
    qtn3.setRPY(0,0,0);//输入的是欧拉角的弧度值

    tfs3.transform.rotation.x = qtn3.getX();//获取欧拉角对应的四元数
    tfs3.transform.rotation.y = qtn3.getY();
    tfs3.transform.rotation.z = qtn3.getZ();
    tfs3.transform.rotation.w = qtn3.getW();

    pub.sendTransform(tfs);//发布
    pub.sendTransform(tfs2);//发布
    pub.sendTransform(tfs3);//发布

     ros::Subscriber Msg_sub = node.subscribe<scout_msg::ScoutStatus> ("ScoutStatus", 10,setodom);
     
     ros::spin();

    return 0;
}