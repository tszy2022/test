#include <iostream>
#include "test_connect.h"
#include <unistd.h>
#include <sstream>
#include "ros/ros.h"
#include "std_msgs/String.h"
#include "geometry_msgs/Twist.h"
#include "math.h"
#include "scout_msg/ScoutStatus.h"
#include <iostream>
#include <random>
#include <memory>
#include <functional>
#include <tf/transform_broadcaster.h>
#include<tf2_ros/static_transform_broadcaster.h>
#include <geometry_msgs/TransformStamped.h>
#include<tf2/LinearMath/Quaternion.h>
//#include "scout_msgs/ScoutBmsStatus"

//class Connector;
//scout_msg::ScoutStatus mystate;
geometry_msgs::Twist cmd;
 double deltat=0;
test_connect ioport(500);
void recv(const geometry_msgs::Twist & cmdrecv);

int main(int argc, char **argv)
{
  scout_msg::ScoutStatus mystate;
 ros::init(argc, argv, "mainnode");
  ros::NodeHandle connector_handle;

 
 tf::TransformBroadcaster  tfbr;
  // 创建一个Publisher，发布名为chatter的topic，消息类型为std_msgs::String
  ros::Publisher Msg_pub = connector_handle.advertise<scout_msg::ScoutStatus> ("ScoutStatus", 10);
  ros::Rate loop_rate(5);
 if(ioport.init())
 {
  ros::Subscriber Cmd_sub = connector_handle.subscribe("ScoutMotionCmd", 10, recv);
 while(ros::ok())
    {
     Msg_pub.publish(ioport.status_msg);
// 	// 循环等待回调函数
   ros::spinOnce();
   printf("linear_vel:%lf m/s \n",ioport.scout_state.linear_velocity);
   printf("angular_velocity:%lf rad/s \n",ioport.scout_state.angular_velocity);
// 	// 按照循环频率延时
  loop_rate.sleep();
    }
 }
 else
 {
     ROS_ERROR("init failed");
 }
 
}

void recv(const geometry_msgs::Twist & cmdrecv)
{
memcpy(&cmd,&cmdrecv,sizeof(cmdrecv));
ioport.SetMotionCommand(cmd.linear.y,0,cmd.angular.z, ioport.current_motion_cmd_.fault_clear_flag);
ioport.SendMotionCmd();
}
