#include<ros/ros.h>
#include "message_filters/subscriber.h"
#include "sensor_msgs/LaserScan.h"
#include <math.h>
#include "std_msgs/String.h"
#include "stop_test.h"


stop_test::stop_test(ros::NodeHandle nh)
{
    ROS_INFO("stop_test");
    pubwarn = nh.advertise<obstacle_avoidance::motioncmd>("warner",10);
    sub_ = new message_filters::Subscriber<sensor_msgs::LaserScan>(nh, "scan", 5);
    sub_->registerCallback(boost::bind(&stop_test::backwarner, this, _1));
    warner.warner = warngo;
}

stop_test::~stop_test()
{
}

int stop_test::backwarner(const sensor_msgs::LaserScan::ConstPtr &msg)
{
    //ROS_INFO("backwarner");
    double x;
    double y;
    double ymin = 10.0;
    double xmin = -10.0;
    double xmax = 10.0;
    double rangel = 10.0;
    double ranger = 10.0;
    double rangey = 10.0;
    double angle;
    bool tonoth;
    bool tosouth;
    bool gostra;


    for(int i=0;i<msg->ranges.size();i++)
    {
        angle = i*msg->angle_increment+msg->angle_min;
        x=msg->ranges[i]*sin(angle);
        y = msg->ranges[i]*cos(angle)+juli;
        double range = hypot(x,y);
        if(x<0&&y<=ymea)//探测车辆右方的最近距离
        {
            if(x>=xmin)
            {
                xmin = x;
            }
            if(range < ranger)
            {
                ranger = range;
            }
        }
        if(x>-xmea&&x<xmea)//探测前方的最近距离
        {
             if(y<ymin)
            {
                ymin = y;
            }
            if(range < rangey)
            {
                rangey = range;
            }
        }
        if(x>0&&y<=ymea)//探测左方的最近距离
        {
            if(x<xmax)
            {
                xmax=x;
            }
            if(range < rangel)
            {
                rangel = range;
            }
        }
    }
    




    if(ymin<=ylim)//要转向了
    {
        if(rangel>=rangex&&ranger>=rangex)//判断是否能够旋转
        {
            if(xmax>=-xmin)//判断向哪个方向旋转
                warner.warner = warnleft;
            else
                warner.warner = warnright;
        }
        else
            warner.warner = warnstop;
    }
    else
    {
        if(xmax<=xlim && xmin <= -xlim)
            warner.warner = noleft;
        if(xmin>=-xlim && xmax >= xlim)
            warner.warner = noright;
        if(xmin>=-xlim && xmax<=xlim)
            warner.warner = onlygo;
        if(xmax>xlim&&xmin<-xlim)
        warner.warner = warngo;
    }
    
   // ROS_INFO("warner=%d\n rangel=%.2f\nranger",warner.warner,rangel,ranger);
    

    pubwarn.publish(warner);
}


