#ifndef TRACKMAP_H
#define TRACKMAP_H

#include "ros/ros.h"
#include "geometry_msgs/Twist.h"
#include <message_filters/subscriber.h>
#include <tf2_ros/transform_listener.h>
#include<tf2_ros/buffer.h>
#include<geometry_msgs/TransformStamped.h>
#include<tf2/LinearMath/Quaternion.h>
#include <tf2/transform_datatypes.h>
#include <tf2/LinearMath/Matrix3x3.h>
#include "obstacle_avoidance/track.h"
#include "include/yaml-cpp/yaml.h"
#include <thread>

#ifndef PI
#define PI 3.1415926
#endif

#define dangle 0.01048
#define dlength 0.01
#define lvy 0.1
#define lwz 0.1
#define wmax 0.2
#define wmin 0.05236
#define vmax 0.3
#define vmin 0.05

class trackmap
{
private:
    ros::Publisher cmdpub;
    ros::ServiceServer servertrack;
    ros::ServiceClient clienttrack;
    bool trackback(obstacle_avoidance::track::Request & reqtrack , obstacle_avoidance::track::Response &restrack);
public:

    double roll;
    double pitch;
    double yam;
    double yamm;

        double vy;
        double wz;
        double times;

        double lengths;
        double angles;
        double detaang;

        YAML::Node mappoint;
    

    obstacle_avoidance::track track;
    geometry_msgs::Twist pubcmd;
    tf2_ros::Buffer buffer;
    
    geometry_msgs::TransformStamped trans;
    std::thread client_thread;
    
    void start_client_thread(ros::NodeHandle nh);
    void Client_thread();
    


    trackmap(ros::NodeHandle nh);
    ~trackmap();
};




#endif