#include <ros/ros.h>
#include "setpoint.h"
setpoint::setpoint(ros::NodeHandle nh,double startx,double starty,double endx,double endy)
{
    submap =new message_filters::Subscriber<nav_msgs::OccupancyGrid>(nh, "map", 5);
    submap->registerCallback(boost::bind(&setpoint::responcemap, this, _1));
    pubmap = nh.advertise <nav_msgs::OccupancyGrid>("mappoint",10);
    pubpoint = nh.advertise<geometry_msgs::PointStamped>("point",10);
    tf2_ros::TransformListener listener(buffer);
    startpoint.point.x = startx;
    startpoint.point.y = starty;
    startpoint.header.stamp = ros::Time::now();
    startpoint.header.frame_id = "map";
    endpoint.point.x = endx;
    endpoint.point.y = endy;
    startpoint.header.frame_id = "map";
    endpoint.header.stamp = ros::Time::now();
    firstgot = false;

}

setpoint::~setpoint()
{
}

void setpoint::responcemap(const nav_msgs::OccupancyGrid::ConstPtr &msg)
{
    mapsub.map.data = msg->data;
    mapsub.map.header = msg->header;
    mapsub.map.info = msg->info;
    void transpoint();
    pubmap.publish(mapsub.map);
    pubpoint.publish(startpoint);
    trans = buffer.lookupTransform("laser","map",ros::Time(0));
    

}


void setpoint::transpoint()
{
    int x=startpoint.point.x/mapsub.map.info.resolution+mapsub.map.info.width/2;
    int y = startpoint.point.y/mapsub.map.info.resolution+mapsub.map.info.height/2;
    mapsub.map.data[mapsub.map.info.width*x+y]=100;
    x=endpoint.point.x/mapsub.map.info.resolution+mapsub.map.info.width/2;
    y =endpoint.point.y/mapsub.map.info.resolution+mapsub.map.info.height/2;
    mapsub.map.data[mapsub.map.info.width*x+y]=100;
    
}
