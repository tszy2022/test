#ifndef TEST_CONNECY_H
#define TEST_CONNECT_H

#include<connector_base.h>

class test_connect : public Connector
{
private:
    /* data */
public:

    test_connect(int baud);

    // 向对端发送报文
    int  Send(const void *buf,const int buflen);
    // 接收对端的报文
    int  Recv(void *buf,const int buflen);
    //桌面
    int Read(void *buf,const int buflen);
    int Write(void *buf,const int buflen);

    int init();
    void unpack_all();
    void printall();
    

    
    
    void cmd_test();
};






#endif